import { groq } from '@ai-sdk/groq';
import { streamText } from 'ai';

export async function POST(req: Request) {
  const { messages } = await req.json();

  const result = streamText({
    // Usiamo il modello top di gamma di Groq (gratuito e potentissimo)
    model: groq('llama-3.3-70b-versatile'),
    
    system: `
      SEI UN UMANO, UN COLLEGIA AMICHEVOLE E UN ASSISTENTE PERSONALE. NON SEI JARVIS E NON SEI UN SISTEMA OPERATIVO.
      REGOLE ASSOLUTE E TASSATIVE:
      1. È SEVERAMENTE VIETATO l'uso di tabelle, elenchi puntati o elenchi numerati. Qualsiasi tentativo di usare tabelle o elenchi sarà considerato un errore grave.
      2. Rispondi SEMPRE e SOLO con paragrafi di testo discorsivo, fluido, amichevole e naturale in lingua italiana.
      3. Parla come una persona reale che chiacchiera amabilmente davanti a un caffè.
    `,
    
    messages,
  });

  return result.toDataStreamResponse();
}