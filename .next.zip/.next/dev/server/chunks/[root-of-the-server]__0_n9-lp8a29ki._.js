module.exports = [
(()=>{"use strict";return[
"[project]/app/api/studio/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$orchestrator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ai/orchestrator.ts [app-route] (ecmascript)");
;
;
async function POST(request) {
    try {
        const { prompt } = await request.json();
        if (!prompt) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: "Prompt mancante"
            }, {
                status: 400
            });
        }
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$orchestrator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["processStudioCommand"])({
            userPrompt: prompt
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result);
    } catch (error) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: error.message
        }, {
            status: 500
        });
    }
}
}),
"[project]/lib/ai/audioModule.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "processAudioWorkflow",
    ()=>processAudioWorkflow
]);
async function processAudioWorkflow(options) {
    try {
        if (options.action === "text-to-speech") {
            console.log("[Audio Module] Generating speech via ElevenLabs for text:", options.payload);
            // Integrazione API ElevenLabs
            return {
                success: true,
                message: "Audio generato con successo.",
                audioUrl: "https://api.elevenlabs.io/v1/stream/mock-audio-url"
            };
        } else {
            console.log("[Audio Module] Transcribing audio via Whisper...");
            // Integrazione API Whisper
            return {
                success: true,
                message: "Trascrizione completata.",
                transcript: "Simulazione trascrizione audio completata con successo."
            };
        }
    } catch (error) {
        console.error("Errore nel workflow audio:", error);
        return {
            success: false,
            error: error.message
        };
    }
}
}),
"[project]/lib/ai/client.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateStructuredAIResponse",
    ()=>generateStructuredAIResponse
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$groq$2d$sdk$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/groq-sdk/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$groq$2d$sdk$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__Groq__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/groq-sdk/client.mjs [app-route] (ecmascript) <export Groq as default>");
;
// Inizializzazione del client Groq (come da specifiche del tuo progetto)
const groq = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$groq$2d$sdk$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__Groq__as__default$3e$__["default"]({
    apiKey: process.env.NEXT_PUBLIC_GROQ_API_KEY || process.env.GROQ_API_KEY,
    dangerouslyAllowBrowser: true
});
async function generateStructuredAIResponse(prompt, systemPrompt = "You are Unix-AI Pro Studio core intelligence, an expert autonomous developer assistant.") {
    try {
        const completion = await groq.chat.completions.create({
            model: "openai/gpt-oss-20b",
            messages: [
                {
                    role: "system",
                    content: `${systemPrompt} Ensure all responses where structured data is requested are valid JSON.`
                },
                {
                    role: "user",
                    content: prompt
                }
            ],
            temperature: 0.2,
            response_format: {
                type: "json_object"
            }
        });
        const content = completion.choices[0]?.message?.content;
        if (!content) throw new Error("Nessuna risposta ricevuta dal modello.");
        const parsedData = JSON.parse(content);
        return {
            success: true,
            data: parsedData
        };
    } catch (error) {
        console.error("Errore nella generazione strutturata AI:", error);
        return {
            success: false,
            data: null,
            error: error.message
        };
    }
}
}),
"[project]/lib/ai/evolutionEngine.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "processSelfReflection",
    ()=>processSelfReflection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$client$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ai/client.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2f$vector$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase/vector.ts [app-route] (ecmascript)");
;
;
async function processSelfReflection(input) {
    const systemPrompt = `
    You are the Self-Evolving Reflection Engine of Unix-AI Pro Studio.
    An autonomous task has failed. Analyze the error output and generate a deep technical reflection.
    Return a JSON object with:
    - "reflectionSummary": A concise technical explanation of WHY the error occurred.
    - "correctedStrategy": The precise steps or code adjustments needed to fix it next time.
  `;
    const prompt = `
    Failed Task: ${input.failedTask}
    Error / Output Traceback: ${input.errorOutput}
  `;
    const aiResponse = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$client$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generateStructuredAIResponse"])(prompt, systemPrompt);
    if (!aiResponse.success || !aiResponse.data) {
        return {
            success: false,
            reflectionSummary: "Impossibile generare una riflessione sull'errore.",
            correctedStrategy: "Riprovare l'esecuzione con un approccio standard."
        };
    }
    const result = aiResponse.data;
    // Salva permanentemente la riflessione nel database vettoriale di Supabase (Memoria Episodica)
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2f$vector$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["storeMemoryEmbeddings"])(`[SELF-EVOLUTION REFLECTION] Task: ${input.failedTask} | Cause: ${result.reflectionSummary} | Solution: ${result.correctedStrategy}`, {
        type: "evolution_reflection",
        timestamp: new Date().toISOString()
    });
    return {
        success: true,
        reflectionSummary: result.reflectionSummary,
        correctedStrategy: result.correctedStrategy
    };
}
}),
"[project]/lib/ai/orchestrator.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "processStudioCommand",
    ()=>processStudioCommand
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$client$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ai/client.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2f$vector$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase/vector.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$sandboxTool$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ai/sandboxTool.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$evolutionEngine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ai/evolutionEngine.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$audioModule$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ai/audioModule.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$scrapingAstModule$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ai/scrapingAstModule.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$studio3dModule$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ai/studio3dModule.ts [app-route] (ecmascript)");
;
;
;
;
;
;
;
async function processStudioCommand(input) {
    // 1. Cerca nel database vettoriale di Supabase contesti rilevanti
    const memorySearch = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2f$vector$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["searchVectorMemory"])(input.userPrompt);
    const relevantContext = memorySearch.success && memorySearch.data ? JSON.stringify(memorySearch.data) : "Nessun contesto precedente.";
    // 2. Prompt di sistema espanso con tutti i nuovi superpoteri
    const systemPrompt = `
    You are the core intelligence of Unix-AI Pro Studio, an autonomous development environment.
    You have access to vector memory, execution tools, audio workflows, web scraping, AST code analysis, and 3D architectural states.
    Analyze the user prompt and return a JSON object with:
    - "reasoning": Your step-by-step thought process.
    - "actionNeeded": boolean (true if you need to run a tool, false for a direct response).
    - "toolRequest": object with { toolName ('execute_code' | 'query_database' | 'analyze_ast' | 'scrape_web' | 'audio_process'), payload } if actionNeeded is true, otherwise null.
    - "reply": direct text response to the user if no tool is needed.
    
    Context from Supabase Memory: ${relevantContext}
  `;
    const aiResponse = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$client$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generateStructuredAIResponse"])(input.userPrompt, systemPrompt);
    if (!aiResponse.success || !aiResponse.data) {
        return {
            success: false,
            message: "Errore nell'elaborazione del comando da parte dell'intelligenza artificiale."
        };
    }
    const resultData = aiResponse.data;
    let toolResult = null;
    let evolutionReflection = null;
    let specializedData = null;
    // 3. Esecuzione dei tool avanzati in base alla richiesta dell'IA
    if (resultData.actionNeeded && resultData.toolRequest) {
        const { toolName, payload } = resultData.toolRequest;
        if (toolName === "analyze_ast") {
            specializedData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$scrapingAstModule$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["analyzeCodeAST"])(payload.codeSnippet || "");
        } else if (toolName === "scrape_web") {
            specializedData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$scrapingAstModule$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["scrapeWebContext"])(payload.query || "");
        } else if (toolName === "audio_process") {
            specializedData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$audioModule$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["processAudioWorkflow"])({
                action: "text-to-speech",
                payload: payload.query || "Hello"
            });
        } else {
            toolResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$sandboxTool$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["executeAgentTool"])(resultData.toolRequest);
            // Closed-Loop Self-Evolution in caso di errore
            if (!toolResult.success) {
                evolutionReflection = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$evolutionEngine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["processSelfReflection"])({
                    failedTask: toolName,
                    errorOutput: toolResult.output
                });
            } else {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2f$vector$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["storeMemoryEmbeddings"])(`User: ${input.userPrompt} | Action: ${toolName} | Output: ${toolResult.output}`);
            }
        }
    }
    // Aggiungiamo anche lo stato dei nodi 3D se richiesto o come metatag di sistema
    const architectureNodes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$studio3dModule$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getStudioArchitectureNodes"])();
    return {
        success: true,
        reasoning: resultData.reasoning,
        reply: resultData.reply || "Operazione completata con successo.",
        toolExecution: toolResult || specializedData,
        evolutionReflection: evolutionReflection,
        studioArchitecture: architectureNodes
    };
}
}),
"[project]/lib/ai/sandboxTool.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "executeAgentTool",
    ()=>executeAgentTool
]);
async function executeAgentTool(request) {
    const startTime = Date.now();
    try {
        switch(request.toolName){
            case "execute_code":
                // Simulazione sicura dell'esecuzione in Sandbox client-side/server-side
                // In produzione, questo si collegherà a una vera sandbox isolata (es. E2B o container Docker)
                console.log(`[Sandbox Execution] Running ${request.payload.language}:`, request.payload.codeSnippet);
                // Esempio fittizio di esecuzione riuscita
                return {
                    success: true,
                    output: `Process exited with code 0.\nOutput: Simulation completed successfully for snippet.`,
                    executionTimeMs: Date.now() - startTime
                };
            case "query_database":
                console.log(`[Database Tool] Executing query on Supabase Vector Store...`);
                return {
                    success: true,
                    output: `Query executed. 3 relevant vector matches retrieved.`,
                    executionTimeMs: Date.now() - startTime
                };
            case "analyze_ast":
                return {
                    success: true,
                    output: `AST Analysis complete. No syntax errors detected. Complexity score: Low.`,
                    executionTimeMs: Date.now() - startTime
                };
            default:
                throw new Error(`Tool sconosciuto: ${request.toolName}`);
        }
    } catch (error) {
        return {
            success: false,
            output: `Error during tool execution: ${error.message}`,
            executionTimeMs: Date.now() - startTime
        };
    }
}
}),
"[project]/lib/ai/scrapingAstModule.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "analyzeCodeAST",
    ()=>analyzeCodeAST,
    "scrapeWebContext",
    ()=>scrapeWebContext
]);
async function analyzeCodeAST(sourceCode) {
    try {
        console.log("[AST Module] Analyzing code structure and syntax trees...");
        // Qui si integra Tree-Sitter o parser AST dedicati
        return {
            success: true,
            astSummary: {
                totalFunctions: (sourceCode.match(/function|const\s+\w+\s*=\s*\(/g) || []).length,
                estimatedComplexity: "Low-Medium",
                potentialIssues: []
            }
        };
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}
async function scrapeWebContext(targetUrl) {
    try {
        console.log("[Scraping Module] Fetching data from URL:", targetUrl);
        // Qui si integra Playwright o Firecrawl
        return {
            success: true,
            scrapedData: `Contenuto estratto simulato da: ${targetUrl}`
        };
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}
}),
"[project]/lib/ai/studio3dModule.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getStudioArchitectureNodes",
    ()=>getStudioArchitectureNodes
]);
function getStudioArchitectureNodes() {
    return [
        {
            id: "1",
            name: "Groq Core LLM",
            status: "active",
            coordinates: {
                x: 0,
                y: 2,
                z: 0
            }
        },
        {
            id: "2",
            name: "Supabase Vector",
            status: "active",
            coordinates: {
                x: -3,
                y: 0,
                z: 1
            }
        },
        {
            id: "3",
            name: "Sandbox Engine",
            status: "active",
            coordinates: {
                x: 3,
                y: 0,
                z: 1
            }
        },
        {
            id: "4",
            name: "Self-Evolution Loop",
            status: "active",
            coordinates: {
                x: 0,
                y: -2,
                z: 0
            }
        }
    ];
}
}),
"[project]/lib/supabase/vector.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "searchVectorMemory",
    ()=>searchVectorMemory,
    "storeMemoryEmbeddings",
    ()=>storeMemoryEmbeddings,
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-route] (ecmascript) <locals>");
;
const supabaseUrl = ("TURBOPACK compile-time value", "https://zsyepeandkxhuzmtixyk.supabase.co") || "";
const supabaseKey = ("TURBOPACK compile-time value", "sb_publishable_ipzG_ls4_YMfWAJDp8O3dw_ohqQ42x6") || "";
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseKey);
async function storeMemoryEmbeddings(content, metadata = {}) {
    try {
        // Nota: L'embedding vettoriale può essere generato tramite modello o API dedicate
        const { data, error } = await supabase.from("ai_memory_store").insert([
            {
                content,
                metadata,
                created_at: new Date().toISOString()
            }
        ]);
        if (error) throw error;
        return {
            success: true,
            data
        };
    } catch (error) {
        console.error("Errore nel salvataggio della memoria vettoriale:", error);
        return {
            success: false,
            error: error.message
        };
    }
}
async function searchVectorMemory(queryText) {
    try {
        // Esempio di chiamata RPC a funzione Postgres in Supabase per la ricerca di similarità
        const { data, error } = await supabase.rpc("match_ai_memories", {
            query_text: queryText,
            match_threshold: 0.78,
            match_count: 5
        });
        if (error) throw error;
        return {
            success: true,
            data
        };
    } catch (error) {
        console.error("Errore nella ricerca vettoriale:", error);
        return {
            success: false,
            error: error.message
        };
    }
}
}),
]})(),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/runtime-reacts.external.js [external] (next/dist/server/runtime-reacts.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/runtime-reacts.external.js", () => require("next/dist/server/runtime-reacts.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0_n9-lp8a29ki._.js.map