module.exports = [
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/favicon.ico (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.117ezoe8m31dk.ico" + (globalThis["NEXT_CLIENT_ASSET_SUFFIX"] || ''));}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/app/favicon.ico (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 48,
    height: 48
};
}),
"[project]/app/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const handleSubmit = async (e)=>{
    e.preventDefault();
    if (!prompt.trim() || loading) return;
    const userMessage = prompt.trim();
    setPrompt("");
    setMessages((prev)=>[
            ...prev,
            {
                role: "user",
                content: userMessage
            }
        ]);
    setLoading(true);
    setCoreStatus("thinking");
    try {
        const res = await fetch("/api/studio", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                prompt: userMessage
            })
        });
        let data;
        const textResponse = await res.text();
        try {
            data = JSON.parse(textResponse);
        } catch (parseErr) {
            throw new Error(`Risposta non valida dal server (${res.status}): ${textResponse.slice(0, 100)}`);
        }
        if (res.ok && data.success) {
            setMessages((prev)=>[
                    ...prev,
                    {
                        role: "assistant",
                        content: data.reply,
                        reasoning: data.reasoning
                    }
                ]);
            if (voiceEnabled) {
                setCoreStatus("speaking");
                speakJarvis(data.reply, ()=>setCoreStatus("idle"));
            } else {
                setCoreStatus("idle");
            }
        } else {
            setCoreStatus("idle");
            setMessages((prev)=>[
                    ...prev,
                    {
                        role: "assistant",
                        content: `Errore del Server: ${data?.error || res.statusText || "Errore sconosciuto"}`,
                        reasoning: "Impossibile completare l'orchestrazione."
                    }
                ]);
        }
    } catch (err) {
        setCoreStatus("idle");
        setMessages((prev)=>[
                ...prev,
                {
                    role: "assistant",
                    content: `Errore di connessione: ${err.message}`,
                    reasoning: "Verifica la console del terminale per i dettagli."
                }
            ]);
    } finally{
        setLoading(false);
    }
};
}),
"[project]/app/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", (function(__turbopack_context__){

__turbopack_context__.n(__turbopack_context__.i("[project]/app/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__02fbh2n5nxypw._.js.map