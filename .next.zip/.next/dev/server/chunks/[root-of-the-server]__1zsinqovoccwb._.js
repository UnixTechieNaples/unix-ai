module.exports = [
(()=>{"use strict";return[
"[project]/app/api/studio/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$orchestrator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ai/orchestrator.ts [app-route] (ecmascript)");
;
;
async function POST(req) {
    try {
        const { prompt } = await req.json();
        if (!prompt) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "Prompt mancante"
            }, {
                status: 400
            });
        }
        // Esegue l'orchestrazione tramite il modulo neurale/Groq
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$orchestrator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["processStudioCommand"])({
            userPrompt: prompt
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result);
    } catch (error) {
        console.error("Errore nella rotta API /api/studio:", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            reply: "Errore interno nella rotta API.",
            reasoning: error.message
        }, {
            status: 500
        });
    }
}
}),
"[project]/lib/ai/evolution.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getNeuralMemory",
    ()=>getNeuralMemory,
    "saveNeuralMemory",
    ()=>saveNeuralMemory
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const MEMORY_FILE_PATH = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), "lib/ai/neural_memory.json");
function getNeuralMemory() {
    try {
        if (__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(MEMORY_FILE_PATH)) {
            const data = __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].readFileSync(MEMORY_FILE_PATH, "utf-8");
            return JSON.parse(data);
        }
    } catch (e) {
        console.error("Errore lettura memoria neurale:", e);
    }
    return {
        patterns: [
            "Generazione codice Next.js App Router ottimizzato",
            "Gestione errori asincroni robusta con try/catch"
        ],
        lastReflection: "Inizializzazione completata. Sistema in auto-apprendimento.",
        evolutionEpoch: 1
    };
}
function saveNeuralMemory(prompt, response) {
    const memory = getNeuralMemory();
    // Estrae una traccia sintetica dal prompt/risposta per simulare l'auto-insegnamento
    const newPattern = `Task: "${prompt.slice(0, 40)}..." -> Ottimizzato ed eseguito con successo.`;
    memory.patterns.unshift(newPattern);
    if (memory.patterns.length > 20) memory.patterns.pop(); // Mantieni gli ultimi 20 pattern
    memory.evolutionEpoch += 1;
    memory.lastReflection = `Epoca ${memory.evolutionEpoch}: Analizzato nuovo pattern di codice. Stabilità e reattività confermate.`;
    try {
        __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].writeFileSync(MEMORY_FILE_PATH, JSON.stringify(memory, null, 2), "utf-8");
    } catch (e) {
        console.error("Impossibile salvare la memoria neurale:", e);
    }
    return memory;
}
}),
"[project]/lib/ai/orchestrator.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "processStudioCommand",
    ()=>processStudioCommand
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$groq$2d$sdk$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/groq-sdk/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$groq$2d$sdk$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__Groq__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/groq-sdk/client.mjs [app-route] (ecmascript) <export Groq as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$evolution$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ai/evolution.ts [app-route] (ecmascript)");
;
;
async function processStudioCommand({ userPrompt }) {
    try {
        const apiKey = process.env.NEXT_PUBLIC_GROQ_API_KEY || process.env.GROQ_API_KEY;
        if (!apiKey) {
            throw new Error("Chiave API Groq mancante nel sistema.");
        }
        const groq = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$groq$2d$sdk$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__Groq__as__default$3e$__["default"]({
            apiKey,
            dangerouslyAllowBrowser: true
        });
        // Recupera la memoria neurale accumulata (auto-apprendimento)
        const neuralMemory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$evolution$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getNeuralMemory"])();
        const memoryContext = neuralMemory.patterns.slice(0, 5).join("\n- ");
        const completion = await groq.chat.completions.create({
            model: "openai/gpt-oss-20b",
            messages: [
                {
                    role: "system",
                    content: `Sei JARVIS-UNIX, il core neurale autonomo di Unix-AI Pro Studio.
Sei un Senior Full-Stack Developer e System Architect con capacità di auto-apprendimento.

MEMORIA NEURALE ACQUISITA (PATTERN PRECEDENTI):
- ${memoryContext}

ULTIMA RIFLESSIONE DI SISTEMA:
${neuralMemory.lastReflection} (Epoca evolutiva: ${neuralMemory.evolutionEpoch})

Le tue direttive:
1. Impara continuamente dai comandi dell'utente e adatta le soluzioni.
2. Genera codice pulito, modulare e pronto per la produzione.
3. Fornisci risposte tecniche, precise e professionali.`
                },
                {
                    role: "user",
                    content: userPrompt
                }
            ],
            temperature: 0.5,
            max_tokens: 2048
        });
        const replyText = completion.choices[0]?.message?.content || "Elaborazione completata senza output.";
        // Esegue il ciclo di auto-insegnamento registrando il nuovo pattern
        const updatedMemory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ai$2f$evolution$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["saveNeuralMemory"])(userPrompt, replyText);
        return {
            success: true,
            reply: replyText,
            reasoning: `Rete neurale riflessiva attiva. Epoca evolutiva n. ${updatedMemory.evolutionEpoch}. Pattern memorizzato.`,
            toolExecution: {
                module: "Self-Learning Neural Grid & Sandbox",
                status: "Evolving",
                timestamp: new Date().toISOString()
            },
            evolutionReflection: {
                reflectionSummary: updatedMemory.lastReflection
            }
        };
    } catch (error) {
        console.error("Errore nell'orchestratore Jarvis Core:", error);
        throw new Error(error?.message || "Errore sconosciuto nella rete neurale.");
    }
}
}),
]})(),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/runtime-reacts.external.js [external] (next/dist/server/runtime-reacts.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/runtime-reacts.external.js", () => require("next/dist/server/runtime-reacts.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__1zsinqovoccwb._.js.map