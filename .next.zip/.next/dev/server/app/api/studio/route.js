var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/studio/route.js")
R.c("server/chunks/node_modules_1fq0-t_uu_2id._.js")
R.c("server/chunks/[root-of-the-server]__0kut99z70c9rn._.js")
R.c("server/chunks/_next-internal_server_app_api_studio_route_actions_1-gq5b7lengnr.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/studio/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/studio/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
