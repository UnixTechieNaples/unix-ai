(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0cbk-n2kjjn59._.css","static/chunks/node_modules_next_dist_20wefz_f1k6jn._.js","static/chunks/_0p6ywa4id1t5y._.js"],
    source: "entry"
});
